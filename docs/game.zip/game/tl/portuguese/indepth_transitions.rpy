﻿# TODO: Translation updated at 2026-09-21 12:51

# game/indepth_transitions.rpy:56
translate portuguese demo_transitions_5bbc72fe:

    # e "Ren'Py ships with a large number of built-in transitions, and also includes classes that let you define your own."
    e "Ren'Py ships with a large number of built-in transitions, and also includes classes that let you define your own."

# game/indepth_transitions.rpy:60
translate portuguese demo_transitions_menu_3caf78d3:

    # e "What kind of transitions would you like demonstrated?" nointeract
    e "What kind of transitions would you like demonstrated?" nointeract

# game/indepth_transitions.rpy:95
translate portuguese demo_simple_transitions_2b4fbae3:

    # e "Okay, I can tell you about simple transitions. We call them simple because they don't take much in the way of configuration."
    e "Okay, I can tell you about simple transitions. We call them simple because they don't take much in the way of configuration."

# game/indepth_transitions.rpy:97
translate portuguese demo_simple_transitions_4b235ac2:

    # e "But don't let that get you down, since they're the transitions you'll probably use the most in a game."
    e "But don't let that get you down, since they're the transitions you'll probably use the most in a game."

# game/indepth_transitions.rpy:103
translate portuguese demo_simple_transitions_af0431ac:

    # e "The 'dissolve' transition is probably the most useful, blending one scene into another."
    e "The 'dissolve' transition is probably the most useful, blending one scene into another."

# game/indepth_transitions.rpy:109
translate portuguese demo_simple_transitions_5b9f711f:

    # e "The 'Dissolve' function lets you create your own dissolves, taking a different amount of time."
    e "The 'Dissolve' function lets you create your own dissolves, taking a different amount of time."

# game/indepth_transitions.rpy:116
translate portuguese demo_simple_transitions_79816523:

    # e "The 'fade' transition fades to black, and then fades back in to the new scene."
    e "The 'fade' transition fades to black, and then fades back in to the new scene."

# game/indepth_transitions.rpy:118
translate portuguese demo_simple_transitions_141bb95d:

    # e "If you're going to stay at a black screen, you'll probably want to use 'dissolve' rather than 'fade'."
    e "If you're going to stay at a black screen, you'll probably want to use 'dissolve' rather than 'fade'."

# game/indepth_transitions.rpy:123
translate portuguese demo_simple_transitions_f059f4ae:

    # e "You can use 'Fade' to define your own fades. By changing the timing and the color faded to, you can use this for special effects, like flashbulbs."
    e "You can use 'Fade' to define your own fades. By changing the timing and the color faded to, you can use this for special effects, like flashbulbs."

# game/indepth_transitions.rpy:129
translate portuguese demo_simple_transitions_e948905b:

    # e "The 'pixellate' transition pixellates out the old scene, switches to the new scene, and then unpixellates that."
    e "The 'pixellate' transition pixellates out the old scene, switches to the new scene, and then unpixellates that."

# game/indepth_transitions.rpy:131
translate portuguese demo_simple_transitions_6a1ae05f:

    # e "It's probably not appropriate for most games, but we think it's kind of neat."
    e "It's probably not appropriate for most games, but we think it's kind of neat."

# game/indepth_transitions.rpy:134
translate portuguese demo_simple_transitions_bdfcd85a:

    # e "You can use 'Pixellate' to change the details of the pixellation."
    e "You can use 'Pixellate' to change the details of the pixellation."

# game/indepth_transitions.rpy:136
translate portuguese demo_simple_transitions_432f7224:

    # e "Motions can also be used as transitions."
    e "Motions can also be used as transitions."

# game/indepth_transitions.rpy:138
translate portuguese demo_simple_transitions_a20cefa7:

    # "..."
    "..."

# game/indepth_transitions.rpy:140
translate portuguese demo_simple_transitions_0fd4d656:

    # "......"
    "......"

# game/indepth_transitions.rpy:146
translate portuguese demo_simple_transitions_fbf11906:

    # e "Hey! Pay attention."
    e "Hey! Pay attention."

# game/indepth_transitions.rpy:148
translate portuguese demo_simple_transitions_51c1c5b8:

    # e "I was about to demonstrate 'vpunch'... well, I guess I just did."
    e "I was about to demonstrate 'vpunch'... well, I guess I just did."

# game/indepth_transitions.rpy:154
translate portuguese demo_simple_transitions_57f19473:

    # e "We can also shake the screen horizontally, with 'hpunch'. These were defined using the 'Move' function."
    e "We can also shake the screen horizontally, with 'hpunch'. These were defined using the 'Move' function."

# game/indepth_transitions.rpy:156
translate portuguese demo_simple_transitions_fce83e12:

    # e "There's also the 'move' transition, which is confusingly enough defined using the 'MoveTransition' function."
    e "There's also the 'move' transition, which is confusingly enough defined using the 'MoveTransition' function."

# game/indepth_transitions.rpy:164
translate portuguese demo_simple_transitions_1050b6a4:

    # e "The 'move' transition finds images that have changed placement, and slides them to their new place. It's an easy way to get motion in your game."
    e "The 'move' transition finds images that have changed placement, and slides them to their new place. It's an easy way to get motion in your game."

# game/indepth_transitions.rpy:168
translate portuguese demo_simple_transitions_dc776e59:

    # e "That's it for the simple transitions."
    e "That's it for the simple transitions."

# game/indepth_transitions.rpy:175
translate portuguese demo_imagedissolve_transitions_2db67018:

    # e "Perhaps the most flexible kind of transition is the ImageDissolve, which lets you use an image to control a dissolve."
    e "Perhaps the most flexible kind of transition is the ImageDissolve, which lets you use an image to control a dissolve."

# game/indepth_transitions.rpy:177
translate portuguese demo_imagedissolve_transitions_429f8d03:

    # e "This lets us specify very complex transitions, fairly simply. Let's try some, and then I'll show you how they work."
    e "This lets us specify very complex transitions, fairly simply. Let's try some, and then I'll show you how they work."

# game/indepth_transitions.rpy:179
translate portuguese demo_imagedissolve_transitions_1ce501b0:

    # e "There are two ImageDissolve transitions built into Ren'Py."
    e "There are two ImageDissolve transitions built into Ren'Py."

# game/indepth_transitions.rpy:191
translate portuguese demo_imagedissolve_transitions_ea0413be:

    # e "The 'blinds' transition opens and closes what looks like vertical blinds."
    e "The 'blinds' transition opens and closes what looks like vertical blinds."

# game/indepth_transitions.rpy:201
translate portuguese demo_imagedissolve_transitions_12e2e0d0:

    # e "The 'squares' transition uses these squares to show things."
    e "The 'squares' transition uses these squares to show things."

# game/indepth_transitions.rpy:203
translate portuguese demo_imagedissolve_transitions_bbf73d1c:

    # e "I'm not sure why anyone would want to use it, but it was used in some translated games, so we added it."
    e "I'm not sure why anyone would want to use it, but it was used in some translated games, so we added it."

# game/indepth_transitions.rpy:207
translate portuguese demo_imagedissolve_transitions_0ab2902d:

    # e "The most interesting transitions aren't in the standard library."
    e "The most interesting transitions aren't in the standard library."

# game/indepth_transitions.rpy:209
translate portuguese demo_imagedissolve_transitions_54aa9bf9:

    # e "These ones require an image the size of the screen, and so we couldn't include them as the size of the screen can change from game to game."
    e "These ones require an image the size of the screen, and so we couldn't include them as the size of the screen can change from game to game."

# game/indepth_transitions.rpy:215
translate portuguese demo_imagedissolve_transitions_ca316184:

    # e "We can hide things with a 'circleirisin'..."
    e "We can hide things with a 'circleirisin'..."

# game/indepth_transitions.rpy:221
translate portuguese demo_imagedissolve_transitions_b8fdf2b6:

    # e "... and show them again with a 'circleirisout'."
    e "... and show them again with a 'circleirisout'."

# game/indepth_transitions.rpy:227
translate portuguese demo_imagedissolve_transitions_ee427486:

    # e "The 'circlewipe' transitions changes screens using a circular wipe effect."
    e "The 'circlewipe' transitions changes screens using a circular wipe effect."

# game/indepth_transitions.rpy:233
translate portuguese demo_imagedissolve_transitions_6f089276:

    # e "The 'dream' transition does this weird wavy dissolve, and does it relatively slowly."
    e "The 'dream' transition does this weird wavy dissolve, and does it relatively slowly."

# game/indepth_transitions.rpy:239
translate portuguese demo_imagedissolve_transitions_c0b9d74d:

    # e "The 'teleport' transition reveals the new scene one line at a time."
    e "The 'teleport' transition reveals the new scene one line at a time."

# game/indepth_transitions.rpy:246
translate portuguese demo_imagedissolve_transitions_72ba11d4:

    # e "This is the background picture used with the circleirisout transition."
    e "This is the background picture used with the circleirisout transition."

# game/indepth_transitions.rpy:248
translate portuguese demo_imagedissolve_transitions_fc3b3339:

    # e "When we use an ImageDissolve, the white will dissolve in first, followed by progressively darker colors. Let's try it."
    e "When we use an ImageDissolve, the white will dissolve in first, followed by progressively darker colors. Let's try it."

# game/indepth_transitions.rpy:255
translate portuguese demo_imagedissolve_transitions_4327dca2:

    # e "If we give ImageDissolve the 'reverse' parameter, black areas will dissolve in first."
    e "If we give ImageDissolve the 'reverse' parameter, black areas will dissolve in first."

# game/indepth_transitions.rpy:260
translate portuguese demo_imagedissolve_transitions_3a401ee7:

    # e "This lets circleirisin and circleirisout use the same image."
    e "This lets circleirisin and circleirisout use the same image."

# game/indepth_transitions.rpy:267
translate portuguese demo_imagedissolve_transitions_20d9cf6c:

    # e "The teleport transition uses a different image, one that dissolves things in one line at a time."
    e "The teleport transition uses a different image, one that dissolves things in one line at a time."

# game/indepth_transitions.rpy:272
translate portuguese demo_imagedissolve_transitions_906f7800:

    # e "A dissolve only seems to affect parts of the scene that have changed..."
    e "A dissolve only seems to affect parts of the scene that have changed..."

# game/indepth_transitions.rpy:277
translate portuguese demo_imagedissolve_transitions_4b557a29:

    # e "... which is how we apply the teleport effect to a single character."
    e "... which is how we apply the teleport effect to a single character."

# game/indepth_transitions.rpy:285
translate portuguese demo_cropmove_transitions_1711a91e:

    # e "The CropMove transition class provides a wide range of transition effects. It's not used very much in practice, though."
    e "The CropMove transition class provides a wide range of transition effects. It's not used very much in practice, though."

# game/indepth_transitions.rpy:290
translate portuguese demo_cropmove_transitions_6d82cfd7:

    # e "I'll stand offscreen, so you can see some of its modes. I'll read out the mode name after each transition."
    e "I'll stand offscreen, so you can see some of its modes. I'll read out the mode name after each transition."

# game/indepth_transitions.rpy:296
translate portuguese demo_cropmove_transitions_4427c78c:

    # e "We first have wiperight..."
    e "We first have wiperight..."

# game/indepth_transitions.rpy:302
translate portuguese demo_cropmove_transitions_6d1810a1:

    # e "...followed by wipeleft... "
    e "...followed by wipeleft... "

# game/indepth_transitions.rpy:308
translate portuguese demo_cropmove_transitions_1dd1c6a1:

    # e "...wipeup..."
    e "...wipeup..."

# game/indepth_transitions.rpy:314
translate portuguese demo_cropmove_transitions_0ea0fa83:

    # e "...and wipedown."
    e "...and wipedown."

# game/indepth_transitions.rpy:316
translate portuguese demo_cropmove_transitions_c7cb4c16:

    # e "Next, the slides."
    e "Next, the slides."

# game/indepth_transitions.rpy:322
translate portuguese demo_cropmove_transitions_462a442f:

    # e "Slideright..."
    e "Slideright..."

# game/indepth_transitions.rpy:328
translate portuguese demo_cropmove_transitions_f9a2e523:

    # e "...slideleft..."
    e "...slideleft..."

# game/indepth_transitions.rpy:334
translate portuguese demo_cropmove_transitions_20ce3e9c:

    # e "...slideup..."
    e "...slideup..."

# game/indepth_transitions.rpy:340
translate portuguese demo_cropmove_transitions_9e00a7a6:

    # e "and slidedown."
    e "and slidedown."

# game/indepth_transitions.rpy:342
translate portuguese demo_cropmove_transitions_b8a710c1:

    # e "While the slide transitions slide in the new scene, the slideaways slide out the old scene."
    e "While the slide transitions slide in the new scene, the slideaways slide out the old scene."

# game/indepth_transitions.rpy:349
translate portuguese demo_cropmove_transitions_1efb4cd0:

    # e "Slideawayright..."
    e "Slideawayright..."

# game/indepth_transitions.rpy:355
translate portuguese demo_cropmove_transitions_bfb5dfd7:

    # e "...slideawayleft..."
    e "...slideawayleft..."

# game/indepth_transitions.rpy:361
translate portuguese demo_cropmove_transitions_6c1a4a6f:

    # e "...slideawayup..."
    e "...slideawayup..."

# game/indepth_transitions.rpy:367
translate portuguese demo_cropmove_transitions_1f994a7b:

    # e "and slideawaydown."
    e "and slideawaydown."

# game/indepth_transitions.rpy:369
translate portuguese demo_cropmove_transitions_025ef723:

    # e "We also have a couple of transitions that use a rectangular iris."
    e "We also have a couple of transitions that use a rectangular iris."

# game/indepth_transitions.rpy:376
translate portuguese demo_cropmove_transitions_d00d505e:

    # e "There's irisout..."
    e "There's irisout..."

# game/indepth_transitions.rpy:383
translate portuguese demo_cropmove_transitions_016a1e0a:

    # e "... and irisin."
    e "... and irisin."

# game/indepth_transitions.rpy:387
translate portuguese demo_cropmove_transitions_08d753ed:

    # e "It's enough to make you feel a bit dizzy."
    e "It's enough to make you feel a bit dizzy."

# game/indepth_transitions.rpy:393
translate portuguese demo_pushmove_transitions_003e506d:

    # e "The PushMove transitions use the new scene to push the old one out. Let's take a look."
    e "The PushMove transitions use the new scene to push the old one out. Let's take a look."

# game/indepth_transitions.rpy:401
translate portuguese demo_pushmove_transitions_124f375d:

    # "There's pushright..."
    "There's pushright..."

# game/indepth_transitions.rpy:408
translate portuguese demo_pushmove_transitions_ce380ccb:

    # "...pushleft..."
    "...pushleft..."

# game/indepth_transitions.rpy:416
translate portuguese demo_pushmove_transitions_77629638:

    # "...pushdown..."
    "...pushdown..."

# game/indepth_transitions.rpy:424
translate portuguese demo_pushmove_transitions_b7f33c95:

    # "... and pushup. And that's it the for the PushMove-based transitions."
    "... and pushup. And that's it the for the PushMove-based transitions."

# game/indepth_transitions.rpy:434
translate portuguese demo_movetransition_14df0e34:

    # e "The most common MoveTransition is move, which slides around images that have changed position on the screen."
    e "The most common MoveTransition is move, which slides around images that have changed position on the screen."

# game/indepth_transitions.rpy:442
translate portuguese demo_movetransition_84e40422:

    # e "Just like that."
    e "Just like that."

# game/indepth_transitions.rpy:446
translate portuguese demo_movetransition_098ee9f1:

    # e "There are also the moveout and movein transitions."
    e "There are also the moveout and movein transitions."

# game/indepth_transitions.rpy:448
translate portuguese demo_movetransition_09748f81:

    # e "The moveout transitions (moveoutleft, moveoutright, moveouttop, and moveoutbottom) slide hidden images off the appropriate side of the screen."
    e "The moveout transitions (moveoutleft, moveoutright, moveouttop, and moveoutbottom) slide hidden images off the appropriate side of the screen."

# game/indepth_transitions.rpy:450
translate portuguese demo_movetransition_5edf6007:

    # e "The movein transitions (moveinleft, moveinright, moveintop, and moveinbottom) slide in new images."
    e "The movein transitions (moveinleft, moveinright, moveintop, and moveinbottom) slide in new images."

# game/indepth_transitions.rpy:452
translate portuguese demo_movetransition_20946d36:

    # e "Let's see them all in action."
    e "Let's see them all in action."

# game/indepth_transitions.rpy:487
translate portuguese demo_movetransition_569952e3:

    # e "That's it for the moveins and moveouts."
    e "That's it for the moveins and moveouts."

# game/indepth_transitions.rpy:489
translate portuguese demo_movetransition_bbb75540:

    # e "Finally, there are the zoomin and zoomout transitions, which show and hide things using a zoom."
    e "Finally, there are the zoomin and zoomout transitions, which show and hide things using a zoom."

# game/indepth_transitions.rpy:499
translate portuguese demo_movetransition_dc5ccd54:

    # e "And that's all there is."
    e "And that's all there is."

# game/indepth_transitions.rpy:508
translate portuguese demo_alphadissolve_51613c02:

    # e "The AlphaDissolve transition lets you use one displayable to combine two others. Click, and I'll show you an example."
    e "The AlphaDissolve transition lets you use one displayable to combine two others. Click, and I'll show you an example."

# game/indepth_transitions.rpy:518
translate portuguese demo_alphadissolve_7c08cf8b:

    # e "The AlphaDissolve displayable takes a control displayable, usually an ATL transform."
    e "The AlphaDissolve displayable takes a control displayable, usually an ATL transform."

# game/indepth_transitions.rpy:523
translate portuguese demo_alphadissolve_068e3e98:

    # e "To be useful, the control displayable should be partially transparent."
    e "To be useful, the control displayable should be partially transparent."

# game/indepth_transitions.rpy:525
translate portuguese demo_alphadissolve_6a1b6203:

    # e "During an AlphaDissolve, the old screen is used to fill the transparent areas of the image, while the new screen fills the opaque areas."
    e "During an AlphaDissolve, the old screen is used to fill the transparent areas of the image, while the new screen fills the opaque areas."

# game/indepth_transitions.rpy:529
translate portuguese demo_alphadissolve_80a728b6:

    # e "For our spotlight example, the old screen is this all-black image."
    e "For our spotlight example, the old screen is this all-black image."

# game/indepth_transitions.rpy:534
translate portuguese demo_alphadissolve_ce4380eb:

    # e "The new screen is me just standing here."
    e "The new screen is me just standing here."

# game/indepth_transitions.rpy:542
translate portuguese demo_alphadissolve_2e95917b:

    # e "By combining them using AlphaDissolve, we can build a complicated effect out of simpler parts."
    e "By combining them using AlphaDissolve, we can build a complicated effect out of simpler parts."

translate portuguese strings:

    # game/indepth_transitions.rpy:63
    old "Simple Transitions"
    new "Simple Transitions"

    # game/indepth_transitions.rpy:67
    old "ImageDissolve Transitions"
    new "ImageDissolve Transitions"

    # game/indepth_transitions.rpy:71
    old "MoveTransition Transitions"
    new "MoveTransition Transitions"

    # game/indepth_transitions.rpy:75
    old "CropMove Transitions"
    new "CropMove Transitions"

    # game/indepth_transitions.rpy:79
    old "PushMove Transitions"
    new "PushMove Transitions"

    # game/indepth_transitions.rpy:83
    old "AlphaDissolve Transitions"
    new "AlphaDissolve Transitions"

    # game/indepth_transitions.rpy:87
    old "How about something else?"
    new "How about something else?"

